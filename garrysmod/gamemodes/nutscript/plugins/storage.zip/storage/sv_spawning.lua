local PLUGIN = PLUGIN

PLUGIN.definitions = PLUGIN.definitions or {}

PLUGIN.ContainerRefreshRate = 5; -- in seconds - default 600
PLUGIN.ContainerPresets = { };
PLUGIN.ContainerPresetItems = { };
PLUGIN.ContainerPresets[0] = { "None", 0 };
PLUGIN.NextContainerUpdate = CurTime() + PLUGIN.ContainerRefreshRate

function PLUGIN:Think()
	PLUGIN:SpawnThink()
end

function PLUGIN:SpawnThink()
	for _, v in pairs( ents.FindByClass( "nut_storage" ) ) do
		local def = PLUGIN.definitions[v.GetModel(v):lower()]
		if ( PLUGIN:IsEmpty( v:getInv() ) ) then
			if( CurTime() >= PLUGIN.NextContainerUpdate ) then
				PLUGIN.NextContainerUpdate = CurTime() + PLUGIN.ContainerRefreshRate;
				PLUGIN:ContainerReset( v );
				print("Containers refreshed!")
			end
		end
	end
end

function PLUGIN:IsEmpty( inventory )
	local sizew, sizeh = inventory:getSize()
	if ( inventory:canItemFit( 0, 0, sizew, sizeh ) ) then
		return true
	end
end

function PLUGIN:ContainerReset( container )
	local def = PLUGIN.definitions[container.GetModel(container):lower()]
	local preset = PLUGIN.ContainerPresets[def.container];
	local items = PLUGIN.ContainerPresetItems[def.container];
	for i = 1, preset[2] do
		local a = table.Random( items );
		local rarity = a[2];
		local c = math.random( 1, rarity );
		if( c == rarity ) then
			-- set the inventory of the container, a[1] is the item's id and a[2] is the quantity
		end
	end
end

function PLUGIN:AddContainerType( id, name, n )
	PLUGIN.ContainerPresets[id] = { name, n };
	PLUGIN.ContainerPresetItems[id] = { };
	PLUGIN.ContainerInternal = id;
end

function PLUGIN:AddContainerItem( item, rarity )
	table.insert( PLUGIN.ContainerPresetItems[PLUGIN.ContainerInternal], { item, rarity } );
end